const Pool = require("pg").Pool;

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "final_assessment",
  password: "hello",
  port: 5432,
});

module.exports = pool;
