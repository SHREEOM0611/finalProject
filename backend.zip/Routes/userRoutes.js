// // userRoutes.js

const express = require("express");
const router = express.Router();
const {
  createUser,
  login,
  changePassword,
} = require("../Controllers/userController.js");
const { authenticateJWT } = require("../Middleware/authMiddleware.js");

router.post("/createUser", createUser);
router.post("/login", login);

// Protected route example
router.get("/protected", authenticateJWT, (req, res) => {
  res.json({
    success: true,
    message: "Protected route accessed successfully",
    user: req.user,
  });
});

router.put("change-password/:userId", changePassword);

module.exports = router;

// const express = require("express");
// const router = express.Router();
// const { registerUserController } = require("../Controllers/userController");

// // router.post("/register", registerUserController);
// router.get("/user", registerUserController);
// module.exports = router;
