const { pool, updateUserPassword } = require("../Models/userModel.js");
const nodemailer = require("nodemailer");
const jwt = require("jsonwebtoken");
const { generateRandomPassword } = require("../Utils/utils.js");

const transporter = nodemailer.createTransport({
  port: 465,
  host: "smtp.gmail.com",
  auth: {
    user: "omshree.osj18705@gmail.com",
    pass: "xjku culd uhsc vmmr",
  },
  secure: true,
});

const createUser = async (req, res) => {
  // Your create user logic here
  console.log(req.body);
  // const { user_email, password, role } = req.body;
  const { firstname, lastname, email, username, role } = req.body;
  const password = generateRandomPassword(10); // Generates a random password with length 10
  console.log(password);

  try {
    const newUser = await pool.query(
      "INSERT INTO users (firstname, lastname,username, email, password, role) VALUES ($1, $2, $3, $4, $5, $6)",
      [firstname, lastname, username, email, password, role]
    );
change_password_link=
    await transporter.sendMail({
      from: "omshree.osj18705@gmail.com", // Update with your email address
      to: email, // Email address of the newly created user
      subject: "Welcome to Our App",
      html: `
        <p>Hello ${firstname+" "+lastname},</p>
        <p>Welcome to our application!</p>
        <p>Your account has been successfully created with the following details:</p>
        <p>Username: ${username}</p>
        <p>Email: ${email}</p>
        <p>Password: ${password}</p>
        <p>Change Password here: ${}</p>
        <p>Please login with your credentials.</p>
        <p>Thank you!</p>
      `,
    });
    console.log("User added successfully!");
  } catch (err) {
    console.error(err.message);
  }
};

async function changePassword(req, res) {
  const userId = req.params.userId;
  const newPassword = req.body.newPassword;

  try {
    const success = await userModel.updateUserPassword(userId, newPassword);
    if (success) {
      res
        .status(200)
        .json({ success: true, message: "Password changed successfully" });
    } else {
      res
        .status(500)
        .json({ success: false, message: "Failed to change password" });
    }
  } catch (error) {
    console.error("Error changing password:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
}

// exports.changePassword = async (req, res) => {
//     try {
//         // Find the user by ID
//         const user = await User.findById(req.params.id);

//         //const { userId } = req.params.id;
//         const { password } = req.body;

//         // Check if the user exists
//         if (!user) {
//             return res.status(404).json({ error: 'User not found' });
//         }

//         // Update the password with the new password
//         user.password = password;
//         user.hasChanged = true;
//         await user.save();

//         res.status(200).json({ message: 'Password updated successfully' });
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// };

const login = async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await pool.query(
      "SELECT * FROM users WHERE username = $1 AND password = $2",
      [username, password]
    );

    if (user.rows.length === 1) {
      const token = jwt.sign(
        {
          username: user.rows[0].username,
          role: user.rows[0].role, // Include the role in the JWT payload
        },
        "your-secret-key",
        { expiresIn: "1h" }
      );

      res.json({ success: true, token, role: user.rows[0].role }); // Send the role in the response
    } else {
      res.json({ success: false, message: "Invalid username or password" });
    }
  } catch (error) {
    console.error("Error logging in:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};
// app.post("/createUser", async (req, res) => {
//     console.log(req.body);
//     // const { user_email, password, role } = req.body;
//     const { firstname, lastname, email, username, role } = req.body;
//     const password = generateRandomPassword(10); // Generates a random password with length 10
//     console.log(password);

//     try {
//       const newUser = await pool.query(
//         "INSERT INTO users (firstname, lastname,email, password, role) VALUES ($1, $2, $3, $4, $5, $6)",
//         [firstname, lastname, email, username, password, role]
//       );

//       await transporter.sendMail({
//         from: "omshree.osj18705@gmail.com", // Update with your email address
//         to: user_email, // Email address of the newly created user
//         subject: "Welcome to Our App",
//         html: `
//           <p>Hello ${user_email},</p>
//           <p>Welcome to our application!</p>
//           <p>Your account has been successfully created with the following details:</p>
//           <p>Username: ${user_email}</p>
//           <p>Email: ${user_email}</p>
//           <p>Password: ${password}</p>
//           <p>Please login with your credentials.</p>
//           <p>Thank you!</p>
//         `,
//       });
//       console.log("User added successfully!");
//     } catch (err) {
//       console.error(err.message);
//     }
//   });

// const login = async (req, res) => {
//   console.log("entered login backend");
//   const { username, password } = req.body;
//   console.log(req.body);
//   try {
//     console.log("entered login try catch block");

//     const user = await pool.query(
//       "SELECT * FROM users WHERE username = $1 AND password = $2",
//       [username, password]
//     );

//     if (user.rows.length === 1) {
//       // Generate JWT token
//       const token = jwt.sign(
//         { username: user.rows[0].username, role: user.rows[0].role },
//         "shreeom",
//         { expiresIn: "1h" }
//       );

//       res.json({ success: true, token });
//     } else {
//       res.json({ success: false, message: "Invalid username or password" });
//     }
//   } catch (error) {
//     console.error("Error logging in:", error);
//     res.status(500).json({ success: false, message: "Internal server error" });
//   }
// };

module.exports = { createUser, login, changePassword };

// const { registerUser } = require("../Models/userModel");
// const jwt = require("jsonwebtoken");
// const accessTokenSecret = "youraccesstokensecret";
// const db = require("../Models/userModel");
// // const nodemailer = require("nodemailer");

// // const generateRandomPassword = () => {
// //   const characters =
// //     "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
// //   let password = "";
// //   for (let i = 0; i < 8; i++) {
// //     password += characters.charAt(
// //       Math.floor(Math.random() * characters.length)
// //     );
// //   }
// //   return password;
// // };

// // const sendEmail = async (username, email, password) => {
// //   try {
// //     let transporter = nodemailer.createTransport({
// //       host: "smtp.example.com",
// //       port: 587,
// //       secure: false,
// //       auth: {
// //         user: "your_email@example.com",
// //         pass: "your_email_password",
// //       },
// //     });

// // let info = await transporter.sendMail({
// //   from: '"Your App" <your_email@example.com>',
// //   to: email,
// //   subject: "Your New Account",
// //   text: `Hello ${username},\n\nYour account has been created.\n\nYour temporary password is: ${password}\n\nPlease login and change your password.\n\nRegards,\nYour App Team`,
// // });

// //     console.log("Message sent: %s", info.messageId);
// //   } catch (error) {
// //     console.error("Error sending email:", error);
// //   }
// // };

// // const registerUserController = async (req, res) => {
// //   try {
// //     const { username, email, role } = req.body;

// //     const randomPassword = generateRandomPassword();
// //     await registerUser(username, email, randomPassword, role);
// //     await sendEmail(username, email, randomPassword);

// //     res.status(201).json({ message: "User created successfully" });
// //   } catch (error) {
// //     console.error(error);
// //     res.status(500).json({ error: "Internal Server Error" });
// //   }
// // };

// // const login = async (req, res) => {
// //   try {
// //     const result = await db.query("SELECT * FROM users");
// //     const user = await data.find((u) => {
// //       return u.username === username && u.password === password;
// //     });
// //     res.json(result.rows);
// //   } catch (err) {
// //     console.error("Error executing query", err);
// //     res.status(500).send("Error retrieving users");
// //   }
// // };

// const test = async (req, res) => {
//   try {
//     const result = await db.query("SELECT * FROM ");
//     res.json(result.rows);
//   } catch (err) {
//     console.error("Error executing query", err);
//     res.status(500).send("Error retrieving users");
//   }
// };

// module.exports = {
//   // registerUserController,
//   // login,
//   test,
// };
