create database assessment;

create database admin(
    admin_id serial primary key,
    password varchar(15),
role varchar(20)
)

create database admin(
    id serial primary key,
	firstname varchar(25),
	lastname varchar(25),
	username varchar(25),
	email varchar(35),
    password varchar(15),
	role varchar(20)
)