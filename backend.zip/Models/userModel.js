const { Pool } = require("pg");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "final_assessment",
  password: "hello",
  port: 5432,
});

// pool.connect((err, client, release) => {
//   if (err) {
//     return console.error("Error connecting to database:", err.stack);
//   }
//   console.log("Connected to database");

//   // Fetch data from the users table
//   client.query("SELECT * FROM users", (err, result) => {
//     release(); // Release the client back to the pool
//     if (err) {
//       return console.error("Error executing query:", err.stack);
//     }
//     console.log("Data from users table:", result.rows);
//   });
// });

async function updateUserPassword(userId, newPassword) {
  try {
    await pool.query("UPDATE users SET password = $1 WHERE id = $2", [
      newPassword,
      userId,
    ]);
    return true; // Return true if password is updated successfully
  } catch (error) {
    console.error("Error updating user password:", error);
    throw error; // Throw error if password update fails
  }
}

module.exports = {
  pool,
  updateUserPassword,
};
