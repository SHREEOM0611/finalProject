import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import("./loginpage.css");
const LoginPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("admin"); // Default role set to admin
  const navigate = useNavigate();

  const handleLogin = async () => {
    const url = "http://localhost:5000/login";

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();

    if (response.ok) {
      // If response is OK, check data.success
      if (data.success) {
        // Redirect based on role from response
        if (data.role === "admin") {
          navigate("/admin");
        } else if (data.role === "user") {
          navigate("/user");
        } else {
          console.error("Unexpected role received from backend");
        }
      } else {
        alert("Invalid username, password, or role");
      }
    } else {
      // If response is not OK, handle error
      alert("Error: " + data.message);
    }
  };

  return (
    <div className="container">
      <h2>Login Page</h2>
      <div class="form-group">
        <label for="exampleInputEmail1">Email address</label>
        <input
          type="email"
          class="form-control"
          id="exampleInputEmail1"
          aria-describedby="emailHelp"
          placeholder="Enter email"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <small id="emailHelp" class="form-text text-muted">
          We'll never share your email with anyone else.
        </small>
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input
          type="password"
          class="form-control"
          id="exampleInputPassword1"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <button className="btn" onClick={handleLogin}>
        Login
      </button>
    </div>
  );
};

export default LoginPage;
