const express = require("express");
const bodyParser = require("body-parser");
// const { Pool } = require("pg");
const cors = require("cors");
const pool = require("./db");
const nodemailer = require("nodemailer");
// const nodemailer = require('nodemailer');
// const userRoutes = require("./Routes/userRoutes");
const app = express();

// app.use(cors());
app.use(express.json());
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true,
  })
);
const PORT = process.env.PORT || 5000;

// routes

const transporter = nodemailer.createTransport({
  port: 465, // true for 465, false for other ports
  host: "smtp.gmail.com",
  auth: {
    user: "omshree.osj18705@gmail.com",
    pass: "xjku culd uhsc vmmr",
  },
  secure: true,
});

// create user
app.post("/createUser", async (req, res) => {
  console.log(req.body);
  const { user_email, password, role } = req.body;

  try {
    const newUser = await pool.query(
      "INSERT INTO users (user_email, password, role) VALUES ($1, $2, $3)",
      [user_email, password, role]
    );

    await transporter.sendMail({
      from: "omshree.osj18705@gmail.com", // Update with your email address
      to: user_email, // Email address of the newly created user
      subject: "Welcome to Our App",
      html: `
        <p>Hello ${user_email},</p>
        <p>Welcome to our application!</p>
        <p>Your account has been successfully created with the following details:</p>
        <p>Username: ${user_email}</p>
        <p>Password: ${password}</p>
        <p>Please login with your credentials.</p>
        <p>Thank you!</p>
      `,
    });
    console.log("User added successfully!");
  } catch (err) {
    console.error(err.message);
  }
});

app.post("/login", async (req, res) => {
  const { username, password, role } = req.body;

  try {
    // Query the database to check if the user exists and the credentials are correct
    const user = await pool.query(
      "SELECT * FROM users WHERE user_email = $1 AND password = $2",
      [username, password]
    );

    if (user.rows.length === 1) {
      // User found, credentials are correct
      // You can add more checks here based on the user's role if needed
      res.json({ success: true, role: user.rows[0].role });
    } else {
      // No user found or invalid credentials
      res.json({ success: false });
    }
  } catch (error) {
    console.error("Error logging in:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
