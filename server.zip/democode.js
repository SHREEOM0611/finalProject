// // const express = require("express");
// // const bodyParser = require("body-parser");
// // const { Pool } = require("pg");

// // const userRoutes = require("./Routes/userRoutes");

// // const app = express();
// // const PORT = process.env.PORT || 5000;

// // // Create a pool for PostgreSQL connection
// // const pool = new Pool({
// //   user: "postgres",
// //   host: "localhost",
// //   database: "final_assessment",
// //   password: "hello",
// //   port: 5432,
// // });

// // // Function to get users from the database
// // const getUsers = async () => {
// //   const client = await pool.connect();
// //   console.log("connected");
// //   try {
// //     const result = await client.query("SELECT * FROM users");
// //     console.log(result.rows);
// //   } finally {
// //     client.release();
// //   }
// // };

// // getUsers();

// // // Middleware to parse JSON bodies
// // app.use(bodyParser.json());

// // // Route for user-related endpoints
// // app.use("/api/users", userRoutes);

// // // Start the server
// // app.listen(PORT, () => {
// //   console.log(`Server is running on port ${PORT}`);
// // // });
// const Express = require("express");
// const Cors = require("cors");
// const { Pool } = require("pg");
// const Generator = require("generate-password");
// const Nodemailer = require("nodemailer");

// const app = Express();
// app.use(Cors());
// app.use(Express.json());

// // PostgreSQL connection configuration
// const pool = new Pool({
//   user: "postgres",
//   host: "localhost",
//   database: "final_assessment",
//   password: "hello",
//   port: 5432, // Default PostgreSQL port
// });

// // Set up Nodemailer transporter for Outlook
// const transporter = Nodemailer.createTransport({
//   host: "smtp.office365.com",
//   port: 587,
//   secure: false, // true for 465, false for other ports
//   auth: {
//     user: "soumyajit@jmangroup.com", // Your Outlook email address
//     pass: "Jman@600113", // Your Outlook email password
//   },
// });

// app.post("/login", async (req, res) => {
//   // try {
//   //   const client = await pool.connect();
//   //   const result = await client.query('SELECT * FROM first_table');
//   //   const rows = result.rows;
//   //   client.release();
//   //   res.json(rows);
//   // } catch (error) {
//   //   console.error('Error executing query', error);
//   //   res.status(500).json({ error: 'Internal server error' });
//   // }
// });

// app.post("/signup", async (req, res) => {
//   try {
//     const { firstname, lastname, email } = req.body;
//     const password = Generator.generate({ length: 10, numbers: true });

//     const client = await pool.connect();
//     const query =
//       "INSERT INTO application_user(first_name, last_name, email, user_password) VALUES($1, $2, $3, $4)";
//     const values = [firstname, lastname, email, password];
//     await client.query(query, values);
//     client.release();

//     await transporter.sendMail({
//       from: "soumyajit@jmangroup.com",
//       to: email,
//       subject: "Your First-time Password Change Required",
//       text: `Dear ${firstname + " " + lastname},
//               Welcome! We're thrilled to have you onboard.
//               For security purposes, we require all new users to change their temporary password before accessing their account. Please follow these simple steps to set up your new password:
//               1. Visit our website at [YourWebsiteURL].
//               2. Log in using the following credentials:
//                 - Username/Email: ${email}
//                 - Temporary Password: ${password}
//               3. Once logged in, you'll be prompted to create your new password. Make sure to choose a strong password that includes a combination of letters, numbers, and special characters.
//               4. After updating your password, you'll gain access to your account and all its features.
//               If you have any questions or encounter any issues during this process, feel free to reach out to our support team at [SupportEmail] for assistance.
//               Thank you for choosing [Your Company Name]. We look forward to serving you!
//               Sincerely,
//               The Team`,
//     });

//     res.json({ message: "Successful" });
//   } catch (error) {
//     console.error("Error Executing Query: ", error);
//     res.status(500).json({ error: "Internal Server Error" });
//   }
// });

// app.listen(8000, () => {
//   console.log(`Server is running on port 8000`);
// });
