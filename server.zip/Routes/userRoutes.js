// // userRoutes.js

// const express = require("express");
// const router = express.Router();
// const { registerUserController } = require("../Controllers/userController");

// // router.post("/register", registerUserController);
// router.get("/user", registerUserController);
// module.exports = router;
