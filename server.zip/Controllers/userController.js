// const { registerUser } = require("../Models/userModel");
// const jwt = require("jsonwebtoken");
// const accessTokenSecret = "youraccesstokensecret";
// const db = require("../Models/userModel");
// // const nodemailer = require("nodemailer");

// // const generateRandomPassword = () => {
// //   const characters =
// //     "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
// //   let password = "";
// //   for (let i = 0; i < 8; i++) {
// //     password += characters.charAt(
// //       Math.floor(Math.random() * characters.length)
// //     );
// //   }
// //   return password;
// // };

// // const sendEmail = async (username, email, password) => {
// //   try {
// //     let transporter = nodemailer.createTransport({
// //       host: "smtp.example.com",
// //       port: 587,
// //       secure: false,
// //       auth: {
// //         user: "your_email@example.com",
// //         pass: "your_email_password",
// //       },
// //     });

// // let info = await transporter.sendMail({
// //   from: '"Your App" <your_email@example.com>',
// //   to: email,
// //   subject: "Your New Account",
// //   text: `Hello ${username},\n\nYour account has been created.\n\nYour temporary password is: ${password}\n\nPlease login and change your password.\n\nRegards,\nYour App Team`,
// // });

// //     console.log("Message sent: %s", info.messageId);
// //   } catch (error) {
// //     console.error("Error sending email:", error);
// //   }
// // };

// // const registerUserController = async (req, res) => {
// //   try {
// //     const { username, email, role } = req.body;

// //     const randomPassword = generateRandomPassword();
// //     await registerUser(username, email, randomPassword, role);
// //     await sendEmail(username, email, randomPassword);

// //     res.status(201).json({ message: "User created successfully" });
// //   } catch (error) {
// //     console.error(error);
// //     res.status(500).json({ error: "Internal Server Error" });
// //   }
// // };

// // const login = async (req, res) => {
// //   try {
// //     const result = await db.query("SELECT * FROM users");
// //     const user = await data.find((u) => {
// //       return u.username === username && u.password === password;
// //     });
// //     res.json(result.rows);
// //   } catch (err) {
// //     console.error("Error executing query", err);
// //     res.status(500).send("Error retrieving users");
// //   }
// // };

// const test = async (req, res) => {
//   try {
//     const result = await db.query("SELECT * FROM ");
//     res.json(result.rows);
//   } catch (err) {
//     console.error("Error executing query", err);
//     res.status(500).send("Error retrieving users");
//   }
// };

// module.exports = {
//   // registerUserController,
//   // login,
//   test,
// };
