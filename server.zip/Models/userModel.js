// // userModel.js

// const { Pool } = require("pg");

// const pool = new Pool({
//   user: "your_username",
//   host: "localhost",
//   database: "your_database",
//   password: "your_password",
//   port: 5432,
// });

// const registerUser = async (username, email, password, role) => {
//   const client = await pool.connect();
//   try {
//     const queryText =
//       "INSERT INTO users ( email, password, role) VALUES ($1, $2, $3)";
//     await client.query(queryText, [username, email, password, role]);
//   } finally {
//     client.release();
//   }
// };

// module.exports = {
//   registerUser,
// };
