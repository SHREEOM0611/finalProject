create database assessment;

create database admin(
    admin_id serial primary key,
    password varchar(15),
role varchar(20)
)