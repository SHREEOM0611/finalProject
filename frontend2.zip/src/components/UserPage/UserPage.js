import React from "react";
import { Link } from "react-router-dom";
const UserPage = () => {
  // Implement user functionalities here
  return (
    <div>
      <h2>User Page</h2>
      {/* Add functionalities for the user application */}

      {/* <Link to={`/change-password/${userId}`}>Change Password</Link> */}
    </div>
  );
};

export default UserPage;
