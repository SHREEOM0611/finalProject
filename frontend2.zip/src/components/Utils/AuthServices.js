// AuthService.js
import jwt from "jsonwebtoken";

export const saveTokenToStorage = (token) => {
  localStorage.setItem("token", token);
};

export const getTokenFromStorage = () => {
  return localStorage.getItem("token");
};

export const getUserIdFromToken = (token) => {
  try {
    const decodedToken = jwt.decode(token);
    return decodedToken.userId;
  } catch (error) {
    console.error("Error decoding token:", error);
    return null;
  }
};
