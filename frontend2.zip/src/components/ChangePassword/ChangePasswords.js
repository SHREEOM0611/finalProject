// import React, { useState } from "react";
// import { useParams } from "react-router-dom";

// const ChangePasswordForm = () => {
//   const { userId } = useParams();
//   const [oldPassword, setOldPassword] = useState("");
//   const [newPassword, setNewPassword] = useState("");
//   const [confirmPassword, setConfirmPassword] = useState("");
//   const [message, setMessage] = useState("");

//   const handleChangePassword = async (e) => {
//     e.preventDefault();

//     if (newPassword !== confirmPassword) {
//       setMessage("Passwords do not match");
//       return;
//     }

//     // Send request to backend to change password
//     const url = "http://localhost:5000/api/changePassword"; // Update with your backend endpoint
//     const data = { oldPassword, newPassword };

//     try {
//       const response = await fetch(url, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(data),
//       });

//       if (response.ok) {
//         setMessage("Password changed successfully");
//         setOldPassword("");
//         setNewPassword("");
//         setConfirmPassword("");
//       } else {
//         const errorData = await response.json();
//         setMessage(errorData.message || "Failed to change password");
//       }
//     } catch (error) {
//       console.error("Error changing password:", error);
//       setMessage("Failed to change password");
//     }
//   };

//   return (
//     <div>
//       <h2>Change Password</h2>
//       <form onSubmit={handleChangePassword}>
//         <div>
//           <label htmlFor="oldPassword">Old Password:</label>
//           <input
//             type="password"
//             id="oldPassword"
//             value={oldPassword}
//             onChange={(e) => setOldPassword(e.target.value)}
//           />
//         </div>
//         <div>
//           <label htmlFor="newPassword">New Password:</label>
//           <input
//             type="password"
//             id="newPassword"
//             value={newPassword}
//             onChange={(e) => setNewPassword(e.target.value)}
//           />
//         </div>
//         <div>
//           <label htmlFor="confirmPassword">Confirm New Password:</label>
//           <input
//             type="password"
//             id="confirmPassword"
//             value={confirmPassword}
//             onChange={(e) => setConfirmPassword(e.target.value)}
//           />
//         </div>
//         <button type="submit">Change Password</button>
//       </form>
//       {message && <p>{message}</p>}
//     </div>
//   );
// };

// export default ChangePasswordForm;

// ChangePasswordPage.js

import React, { useState } from "react";
// import * as AuthService from "../Utils/AuthServices.js";

const ChangePasswordPage = () => {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setErrorMessage] = useState("");

  const handleChangePassword = async ({userId}) => {
    // const token = AuthService.getTokenFromStorage();
    // const userId = AuthService.getUserIdFromToken(token);
    if (newPassword !== confirmPassword) {
      setErrorMessage("Passwords do not match");
      return;
    }

    try {
      const response = await fetch(
        `http://localhost:5000/api/change-password/${userId}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            // Authorization: `Bearer ${token}`,
            Authorization: true,
          },
          body: JSON.stringify({ newPassword }),
        }
      );

      if (response.ok) {
        // Password changed successfully
        alert("Password changed successfully!");
        // Optionally, you can redirect the user to another page
      } else {
        // Handle error response
        const data = await response.json();
        setErrorMessage(data.message);
      }
    } catch (error) {
      console.error("Error changing password:", error);
      setErrorMessage("Internal server error");
    }
  };

  return (
    <div>
      <h2>Change Password</h2>
      <input
        type="password"
        placeholder="New Password"
        value={newPassword}
        onChange={(e) => setNewPassword(e.target.value)}
      />
      <input
        type="password"
        placeholder="Confirm New Password"
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
      />
      <button onClick={handleChangePassword}>Change Password</button>
    </div>
  );
};

export default ChangePasswordPage;
