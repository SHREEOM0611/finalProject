import React, { useState } from "react";

const AdminPage = () => {
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  // const [password, setPassword] = useState("");
  const [role, setRole] = useState("user");

  const handleCreateUser = async () => {
    const url = "http://localhost:5000/api/createUser";

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
         firstname,
          lastname,
          email,
          username,
          role,
        }),
      });

      if (response.ok) {
        console.log("User added successfully!");
        // Optionally, you can reset the form fields after successful user creation
        setUsername("");

        setRole("user");
      } else {
        console.error("Error adding user:", response.statusText);
      }
    } catch (error) {
      console.error("Error adding user:", error);
    }
  };

  // const sendEmail = async (username, email, password) => {
  //   const emailData = { username,email, password };

  //   try {
  //     const response = await fetch("http://localhost:5000/sendEmail", {
  //       method: "POST",
  //       headers: { "Content-Type": "application/json" },
  //       body: JSON.stringify(emailData),
  //     });

  //     if (response.ok) {
  //       console.log("Email sent successfully!");
  //     } else {
  //       console.error("Error sending email:", response.statusText);
  //     }
  //   } catch (error) {
  //     console.error("Error sending email:", error);
  //   }
  // };

  return (
    <div className="container">
      <h2>Admin Page</h2>

      <h3>Create User</h3>
      <div className="form-group">
        <label htmlFor="createUsername">First Name</label>
        <input
          type="text"
          className="form-control"
          id="createFirstname"
          placeholder="Enter Firstname"
          value={firstname}
          onChange={(e) => setFirstname(e.target.value)}
        />
      </div>
      <div className="form-group">
        <label htmlFor="createUsername">Last Name</label>
        <input
          type="text"
          className="form-control"
          id="createLastname"
          placeholder="Enter Lastname"
          value={lastname}
          onChange={(e) => setLastname(e.target.value)}
        />
      </div>
      <div className="form-group">
        <label htmlFor="createUsername">Username</label>
        <input
          type="text"
          className="form-control"
          id="createUsername"
          placeholder="Enter username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>
      <div className="form-group">
        <label htmlFor="createUsername">Email </label>
        <input
          type="text"
          className="form-control"
          id="createEmail"
          placeholder="Enter Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      {/* <div className="form-group">
        <label htmlFor="createPassword">Password</label>
        <input
          type="password"
          className="form-control"
          id="createPassword"
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div> */}
      <div className="form-group">
        <label htmlFor="selectRole">Role</label>
        <select
          className="form-control"
          id="selectRole"
          value={role}
          onChange={(e) => setRole(e.target.value)}
        >
          <option value="admin">Admin</option>
          <option value="user">User</option>
        </select>
      </div>
      <button className="btn btn-primary" onClick={handleCreateUser}>
        Add User
      </button>
    </div>
  );
};

export default AdminPage;
